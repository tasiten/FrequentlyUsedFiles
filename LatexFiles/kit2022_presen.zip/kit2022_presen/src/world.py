from time import sleep
from random import randint

while True:
    input('push ENTER key')
    r = randint(1,6)
    print( r )
    sleep(0.5)      

        
